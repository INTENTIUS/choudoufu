def handler(e,c):
    return 1
